# # lets_quiz/quiz/__init__.py
# from django.apps import apps
# from .views import *

# def import_models_when_ready():
#     apps.check_apps_ready()

# # Connect the function

# lets_quiz/quiz/__init__.py

default_app_config = 'quiz.app_config.QuizAppConfig'